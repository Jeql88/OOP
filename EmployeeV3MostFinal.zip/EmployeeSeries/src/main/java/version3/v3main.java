/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package version3;

//import com.mycompany.version1.*;

//import com.mycompany.version1.*;

/**
 *
 * @author Josh
 */
public class v3main {

    public static void main(String[] args) {
        HourlyEmployee jio = new HourlyEmployee(new Name("dusky","saballa"),new MyDate(2004,8,5), new MyDate(2024,9,15), 104, 150, 40);
        PieceWorkerEmployee jansen = new PieceWorkerEmployee(new Name("jansen","choi","kai"),new MyDate(2004,8,5), new MyDate(2024,9,15), 104, 15000, 40);
        ComissionEmployee josh = new ComissionEmployee(new Name("josh","lui","que"),new MyDate(2004,5,5), new MyDate(2024,9,15), 104, 15000);
        BasedPlusComissionEmployee dusky = new BasedPlusComissionEmployee(new Name("dusky","saballa","ethan"),new MyDate(2004,5,5), new MyDate(2024,9,15), 104, 15000,14000);
        jio.display();
        jansen.display();
        josh.display();
        dusky.display();
    }
}
