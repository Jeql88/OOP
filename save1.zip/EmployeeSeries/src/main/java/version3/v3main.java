/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package version3;

//import com.mycompany.version1.*;

//import com.mycompany.version1.*;

/**
 *
 * @author Josh
 */
public class v3main {

    public static void main(String[] args) {
        
        HourlyEmployee jio = new HourlyEmployee(new Name("dusky","saballa",'e'),new myDate(2004,8,5), new myDate(2024,9,15), 104, 150, 40);
        jio.display();
    }
}
